<template>
    <div>
        <p>&copy; Fehmi KÖYLÜ Erciyes Üniversitesi Bilgisayar Mühendisliği Bölümü</p>
        <a href="#">Bölüm sayfası</a>
        <a href="#">Alışveriş kuralları</a>
        <a href="#">Destek</a>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
div{
    margin-top: 30px;
}
a{
    display: inline;
    padding: 10px;
}
</style>