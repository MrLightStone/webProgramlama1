<template>
  <div>
    <b-row>
      <b-col md v-for="item in datas" :key="item.id">
        <b-card
          :header="item.name"
          header-tag="header"
        >
        <h1>{{item.price}}₺<span> / {{item.unit}}</span></h1>
          <span>{{item.longname}}</span>
          <b-card-text>{{item.other}}</b-card-text>
          <b-button href="#" variant="primary">Sepete Ekle</b-button>
        </b-card></b-col
      >
    </b-row>
  </div>
</template>

<script>
export default {
    data() {
        return {
            datas: [{
                id: 1,
                name: "Ekmek",
                price: 2,
                unit: "adet",
                longname: "Somun ekmek",
                other: "200gr"
            },{
                id: 2,
                name: "Çikolata",
                price: 5,
                unit: "adet",
                longname: "Bitter çikolata",
                other: "60gr"
            },{
                id: 3,
                name: "Domates",
                price: 6,
                unit: "kg",
                longname: "Domates",
                other: "Antalya Sera"
            }]
        }
    },
    methods: {
        add(data) {
            this.$emit("add", data)
        }
    },
};
</script>

<style scoped>
h1 span{
    font-size: 30px;
    color: rgb(141, 141, 141);
}

span{

}

.btn{
    width: 100%;
}
</style>