<template>
  <div class="bo">
    <b-row>
      <b-col cols="4">
        <b-badge variant="dark">3</b-badge>
        <h4>Siparişleriniz</h4>
        <div class="orders">
          <div v-for="item in orders" :key="item.id" class="order">
            <span>{{ item.name }}({{ item.amount }}) {{ item.price }}TL</span>
            <a href="#">x</a>
            <hr />
          </div>
          <div class="total">
            <span>Toplam fiyat</span>
            <span class="totald"
              >{{
                orders.reduce(function (res, item) {
                  return res + item.price * item.amount;
                }, 0)
              }}₺</span
            >
          </div>
        </div>
        <div class="discount">
          <b-input-group>
            <b-form-input></b-form-input>
            <b-input-group-append>
              <b-button variant="info">Kupon gir</b-button>
            </b-input-group-append>
          </b-input-group>
        </div>
      </b-col>
    </b-row>
  </div>
</template>

<script>
export default {
  data() {
    return {
      orders: [
        {
          id: 1,
          name: "Ekmek",
          price: 2,
          amount: 2,
        },
        {
          id: 2,
          name: "Çikolata",
          price: 5,
          amount: 2,
        },
        {
          id: 3,
          name: "Domates",
          price: 6,
          amount: 2,
        },
      ],
    };
  },
  methods: {
  },
};
</script>

<style scoped>
.bo {
  margin-top: 20px;
  text-align: left;
}
.badge {
  position: absolute;
  right: 0;
  font-size: 15px;
  border-radius: 200px;
}
.orders {
  border: 1px solid #000;
}
.orders .order span {
  padding: 0 10px;
}
a {
  position: absolute;
  right: 30px;
  color: rgb(184, 0, 0);
  text-decoration: none;
}
.total {
  padding: 0 10px 10px 10px;
}
.totald {
  font-weight: bold;
  position: absolute;
  right: 30px;
}
.discount {
  border: 1px solid #000;
  padding: 10px;
  margin-top: 20px;
}
.input-group{
    width: 100%;
}
</style>