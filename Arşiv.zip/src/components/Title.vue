<template>
    <div>
        <img src="../assets/bm.png" alt="bm">
        <br>
        <br>
        <h3>Eriyes Üniversitesi Bilgisayar Mühendisliği Bölümü Web Programlama 1 dersi final sorusu</h3>
        <h4>Dr. Öğr. Üyesi Fehim Köylü</h4>
        <h1>Alışveriş Uygulaması</h1>
        <p>Vermek istediğiniz siparişler için aşağıdaki listeden seçerek adedini belirtiniz.</p>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
h3{
    color: rgb(90, 90, 90);
}
</style>