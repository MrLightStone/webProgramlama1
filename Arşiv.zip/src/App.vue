<template>
  <div id="app" class="container">
    <Title></Title>
    <Product v-on:add="add"></Product>
    <Order :order="order"></Order>
    <Footer></Footer>
  </div>
</template>

<script>

export default {
  name: 'App',
  components: {
    Title:()=>import("./components/Title"),
    Product:()=>import("./components/Product"),
    Order:()=>import("./components/Order"),
    Footer:()=>import("./components/Footer")
  },
  data() {
    return {
      order: {}
    }
  },
  methods: {
    add(value) {
      this.order = value;
    }
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>